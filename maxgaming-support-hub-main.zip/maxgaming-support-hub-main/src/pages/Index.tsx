import { useState, useMemo, useRef, useEffect } from "react";
import { Search, X } from "lucide-react";
import { brands, deepSearch, SearchResult } from "@/data/brands";
import BrandCard from "@/components/BrandCard";
import Header from "@/components/Header";

const Index = () => {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  
  const results: SearchResult[] = useMemo(() => {
    if (!query.trim()) return brands.map((b) => ({ brand: b }));
    return deepSearch(query);
  }, [query]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "/" && !["INPUT", "TEXTAREA"].includes((e.target as HTMLElement)?.tagName)) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero section */}
      <section className="border-b border-border">
        <div className="container py-12 md:py-20">
          <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground">
            RMA Support <span className="text-gradient-primary">Center</span>
          </h1>
          <p className="mt-4 max-w-2xl text-lg text-muted-foreground">
            Troubleshoot your product before submitting an RMA claim. Select your brand below or search for your specific issue.
          </p>

          {/* Search bar */}
          <div className="relative mt-8 max-w-xl">
            <Search className="absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
            <input
              ref={inputRef}
              type="text"
              placeholder="Search brands, products, or issues... (press / to focus)"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="h-12 w-full rounded-lg border border-border bg-card pl-12 pr-10 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50 transition-all"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 rounded-md p-1 text-muted-foreground hover:text-foreground transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          {query && (
            <p className="mt-3 text-sm text-muted-foreground">
              {results.length} result{results.length !== 1 ? "s" : ""} found
            </p>
          )}
        </div>
      </section>

      {/* Brand grid */}
      <section className="container py-8 md:py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {results.map((result) => (
            <BrandCard
              key={result.brand.id}
              brand={result.brand}
              matchInfo={
                result.matchedIssue
                  ? `${result.matchedCategory} → ${result.matchedIssue}`
                  : result.matchedCategory
              }
            />
          ))}
        </div>
        {results.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 text-center">
            <Search className="h-12 w-12 text-muted-foreground mb-4" />
            <h2 className="font-display text-xl font-semibold text-foreground">No results found</h2>
            <p className="mt-2 text-muted-foreground">
              Try a different search term or browse all brands.
            </p>
          </div>
        )}
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container text-center text-sm text-muted-foreground">
          <p>MaxGaming RMA Support Center — Troubleshoot before you ship</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
