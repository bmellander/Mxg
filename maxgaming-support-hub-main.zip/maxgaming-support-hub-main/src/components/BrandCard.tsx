import { Link } from "react-router-dom";
import { Brand } from "@/data/brandTypes";
import { ChevronRight } from "lucide-react";

interface BrandCardProps {
  brand: Brand;
  matchInfo?: string;
}

const BrandCard = ({ brand, matchInfo }: BrandCardProps) => {
  const categoryCount = brand.categories.length;

  return (
    <Link
      to={`/brand/${brand.id}`}
      className="group relative flex flex-col justify-between rounded-lg border border-border bg-card p-4 transition-all duration-200 hover:border-primary/40 hover:glow-border hover:translate-y-[-2px]"
    >
      <div>
        <h3 className="font-display font-semibold text-lg text-foreground group-hover:text-primary transition-colors">
          {brand.name}
        </h3>
        {brand.description && (
          <p className="mt-1 text-sm text-muted-foreground line-clamp-2">
            {brand.description}
          </p>
        )}
        {matchInfo && (
          <p className="mt-2 text-xs text-primary truncate">
            Match: {matchInfo}
          </p>
        )}
      </div>
      <div className="mt-3 flex items-center justify-between">
        <div className="flex gap-1 flex-wrap">
          {brand.categories.slice(0, 3).map((cat) => (
            <span
              key={cat.name}
              className="inline-block rounded-md bg-secondary px-2 py-0.5 text-xs text-secondary-foreground"
            >
              {cat.name}
            </span>
          ))}
          {categoryCount > 3 && (
            <span className="inline-block rounded-md bg-secondary px-2 py-0.5 text-xs text-secondary-foreground">
              +{categoryCount - 3}
            </span>
          )}
          {categoryCount === 0 && !brand.directToManufacturer && (
            <span className="inline-block rounded-md bg-secondary px-2 py-0.5 text-xs text-muted-foreground">
              General
            </span>
          )}
          {brand.directToManufacturer && (
            <span className="inline-block rounded-md bg-primary/15 px-2 py-0.5 text-xs text-primary">
              Direct to manufacturer
            </span>
          )}
        </div>
        <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
      </div>
    </Link>
  );
};

export default BrandCard;
