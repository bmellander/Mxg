import { Brand } from "./brandTypes";
import {
  standardMouseCategory,
  standardMousepadCategory,
  standardKeyboardCategory,
  standardKeyboardIssues,
  standardIEMCategory,
  standardControllerCategory,
  standardControllerIssues,
  standardScreenCategory,
  standardRouterCategory,
  standardWirelessHeadphoneCategory,
  standardWiredHeadphoneCategory,
  standardMicrophoneCategory,
  standardCameraCategory,
} from "./sharedTroubleshooting";

export const brands: Brand[] = [
  // ── A ──────────────────────────────────────────────────────────────────
  {
    id: "acer",
    name: "Acer",
    description: "Global electronics and computing brand.",
    links: [],
    categories: [standardRouterCategory, standardScreenCategory],
  },
  {
    id: "akko",
    name: "Akko",
    description: "Peripherals brand known for keyboards and keycaps.",
    links: [
      { label: "FAQ", url: "https://www.akkogear.com/faq/" },
      { label: "Download Center", url: "https://www.akkogear.com/download/" },
      { label: "Web Driver", url: "https://web.akkogear.com/" },
    ],
    categories: [
      {
        name: "Keyboards",
        icon: "Keyboard",
        issues: [
          ...standardKeyboardIssues,
          {
            title: "When I connect the keyboard, a USB error occurs on my PC",
            steps: [
              "Connect the keyboard directly into a different USB port into the motherboard.",
              "Try a different cable.",
              "Restart your computer.",
              "If possible, perform a firmware update.",
            ],
          },
          {
            title: "My Win key has stopped working",
            steps: [
              "It's most likely caused by an accidental lock of Win key. Press Fn+Win to unlock the Win key.",
            ],
          },
        ],
      },
      {
        ...standardMouseCategory,
        issues: [
          ...standardMouseCategory.issues,
          {
            title: "Wireless Receiver / Pairing Issues (dual-receiver models)",
            steps: [
              "For certain Akko wireless mice with two receivers (one for 8K mode and one for 1K mode):",
              "Switching between the 1K and 8K receivers requires re-pairing in the driver software — they don't auto-switch on their own.",
              "Open the Akko driver software → go into the pairing option → put the mouse in pairing mode (hold the pairing button until the LED flashes rapidly) → complete pairing with the selected receiver.",
            ],
          },
          {
            title: "Wired mode recognition problems",
            steps: [
              "Sometimes the mouse light comes on but the device doesn't register on the PC, suggesting USB cable/port issues or driver conflicts.",
              "Reinstalling or updating drivers can help. Try inserting the USB directly into the motherboard.",
            ],
          },
        ],
      },
    ],
  },
  {
    id: "anbernic",
    name: "Anbernic",
    description: "Retro handheld gaming consoles.",
    links: [
      { label: "System Updates", url: "https://anbernic.com/pages/firmware-download" },
    ],
    categories: [
      {
        name: "Handheld Consoles",
        icon: "Gamepad2",
        issues: [
          {
            title: "I did not receive an SD card",
            steps: [
              "Check under the plastic holder; Anbernic accessories are often hidden there.",
              "If it's not there, send the product back, as we do not have spare ones to send out.",
            ],
          },
          {
            title: "I only received 1 SD card",
            steps: [
              "On some models, the operating system and games are on the same SD card.",
              "In these cases, the card should be inserted into the TF1/INT port.",
            ],
          },
          {
            title: "My unit does not start",
            steps: [
              "Insert the SD card (the product's operating system) into the TF1/INT port.",
              "Connect a power cable.",
              "Let the product charge for a few minutes.",
              "Hold down the power button while the power cable is connected.",
            ],
          },
          {
            title: "Stuck on the 'Anbernic' startup screen",
            steps: [
              "Most likely hardware-related and cannot be solved with a simple fix.",
              "Please return the unit to us for troubleshooting.",
            ],
          },
          {
            title: "Some games crash / do not start",
            steps: [
              "The console is sold with a capacity of 14000 games. It is expected that some of these will not work.",
              "We are unable to register a warranty claim based on this. If the issue is frequent, please reach out to our support team.",
            ],
          },
          {
            title: "My screen has fallen out of the case",
            steps: [
              "This is a recurring issue with older models.",
              "Please reach out to our support team if the issue affects the user experience.",
            ],
          },
          {
            title: "My screen has vertical lines",
            steps: [
              "Usually means that the screen is defective.",
              "Please proceed with sending the unit to us for troubleshooting.",
            ],
          },
          {
            title: "Button requires excessive force to register",
            steps: [
              "Please reach out to our support team for further instructions.",
            ],
          },
          {
            title: "General troubleshooting (Anbernic method)",
            steps: [
              "Charge for half an hour longer to see if the charging light will light up.",
              "Remove the SD card, (blow on it), and then reinsert it into TF1.",
              "Press a few more times to reset (or press Power + Volume Down).",
              "When the console is turned off, use a hexagonal screwdriver to open the back shell, remove and reinsert the battery port, then turn it on.",
              "If it still does not work, try to flash the firmware according to the system links.",
              "Above not working, ultimately have to replace the motherboard.",
            ],
          },
          {
            title: "My console came without any pre-installed games",
            steps: [
              "The newer batches do not come with any pre-installed games on them.",
              "To download games, please follow the guide by the manufacturer on their website.",
            ],
          },
        ],
      },
    ],
  },
  {
    id: "aoc",
    name: "AOC",
    description: "Monitor and display manufacturer.",
    links: [],
    categories: [standardScreenCategory],
    directToManufacturer: true,
    contactInfo: "For the best service experience, please proceed with reaching out to AOC themselves, as they prefer to handle these claims themselves. Reaching out to them removes us as a middle man and therefore avoids wasted time in unnecessary handling time, freight and processing.",
    manufacturerUrl: "https://tpvcrmplus.my.salesforce-sites.com/Web2Case/WebformAOC?lang=en_US",
  },
  {
    id: "arbiter-studio",
    name: "Arbiter Studio",
    description: "Premium gaming peripherals brand.",
    links: [
      { label: "Web App", url: "https://www.arbiterstudio.com/pages/web-app" },
      { label: "Firmware", url: "https://www.arbiterstudio.com/pages/download" },
    ],
    categories: [standardMouseCategory, standardKeyboardCategory],
  },
  {
    id: "arozzi",
    name: "Arozzi",
    description: "Gaming furniture, monitors, and peripherals.",
    links: [],
    categories: [
      standardScreenCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
      standardMouseCategory,
    ],
  },
  {
    id: "artisan",
    name: "Artisan",
    description: "Premium Japanese mousepad manufacturer.",
    links: [
      { label: "FAQ", url: "https://www.artisan-jp.com/nj_faq_eng.html" },
    ],
    categories: [
      {
        ...standardMousepadCategory,
        issues: [
          {
            title: "My mousepad has stitch imperfections",
            steps: [
              "According to Artisan's FAQ: stitch fraying or finish differences are not considered DOA.",
              "Minor stitch fraying or finish differences are not considered a defect.",
              "If the imperfection directly impacts functionality or user experience, please reach out to us.",
            ],
          },
          ...standardMousepadCategory.issues.slice(1),
        ],
      },
    ],
  },
  {
    id: "asus",
    name: "Asus",
    description: "Global technology brand for gaming peripherals and components.",
    links: [],
    categories: [
      standardMouseCategory,
      standardKeyboardCategory,
      standardMousepadCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
    ],
  },
  {
    id: "atk",
    name: "ATK",
    description: "Gaming peripherals brand.",
    links: [
      { label: "User Manual", url: "https://www.atkgaminggear.com/pages/user-manual" },
    ],
    categories: [
      standardMouseCategory,
      standardKeyboardCategory,
      standardMousepadCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
    ],
  },

  // ── B ──────────────────────────────────────────────────────────────────
  {
    id: "belkin",
    name: "Belkin",
    description: "Consumer electronics and connectivity solutions.",
    links: [
      { label: "Support Center", url: "https://www.belkin.com/support/" },
    ],
    categories: [],
  },
  {
    id: "benq-zowie",
    name: "BenQ / Zowie",
    description: "Professional gaming monitors, mice, and mousepads by BenQ and Zowie.",
    links: [
      { label: "Zowie FAQ", url: "https://zowie.benq.com/en-us/support/faq.html" },
      { label: "Knowledge Center", url: "https://zowie.benq.com/en-us/support/knowledge.html" },
      { label: "Downloads", url: "https://zowie.benq.com/en-us/support/download.html" },
    ],
    categories: [standardMouseCategory, standardMousepadCategory, standardScreenCategory],
    directToManufacturer: true,
    contactInfo: "For the best service experience, please register your service request directly on BenQ's website. This way you'll be in direct contact with their experts, avoiding unnecessary shipping delays and receiving a quicker solution.",
    manufacturerUrl: "https://zowie.benq.eu/en-eu/support/contact-us/email-us.html#repair",
  },
  {
    id: "bose",
    name: "Bose",
    description: "Premium audio equipment manufacturer.",
    links: [
      { label: "Product Support", url: "https://www.bose.com/support" },
    ],
    categories: [],
    directToManufacturer: true,
    contactInfo: "For the best service experience, please proceed with reaching out to Bose themselves, as they prefer to handle these claims themselves.",
    manufacturerUrl: "https://www.bose.co.uk/en_gb/support/self_service/service_and_repair_request.html",
  },
  {
    id: "brook",
    name: "Brook",
    description: "Gaming accessories and controller adapters.",
    links: [],
    categories: [],
  },

  // ── C ──────────────────────────────────────────────────────────────────
  {
    id: "cherry-xtrfy",
    name: "Cherry Xtrfy",
    description: "Swedish gaming peripherals with a focus on mice and keyboards.",
    links: [
      { label: "Downloads", url: "https://cherryxtrfy.com/downloads" },
    ],
    categories: [standardMouseCategory, standardKeyboardCategory],
  },
  {
    id: "chilkey",
    name: "Chilkey",
    description: "Mechanical keyboard brand with innovative features.",
    links: [
      { label: "Console / Drivers", url: "https://chilkey.com/pages/console" },
    ],
    categories: [
      {
        name: "Keyboards",
        icon: "Keyboard",
        issues: [
          ...standardKeyboardIssues,
          {
            title: "Power issues (possible daughterboard defect)",
            steps: [
              "Please try a different cord and power outlet (USB port) to rule out accessories error.",
              "Possibly a defective daughterboard (or FFC Ribbon). Please film a video of the issue and contact our technical support.",
            ],
          },
          {
            title: "Interactive screen does not work",
            steps: [
              "Make sure that the screen is turned on (please see the product manual for instructions).",
              "Open the case and make sure that the FFC Ribbon cable is mounted correctly.",
              "If the Ribbon is damaged, please reach out to our technical support.",
            ],
          },
          {
            title: "Changes in software aren't saved",
            steps: [
              "Please make sure that you click the 'Sync' button after any changes to the settings of the keyboard.",
            ],
          },
        ],
      },
    ],
    contactInfo: "For the smoothest resolution, please contact Chilkey directly. Their specialists will be able to help with troubleshooting, replacement or equal solutions.",
  },
  {
    id: "cooler-master",
    name: "Cooler Master",
    description: "Gaming hardware and peripherals manufacturer.",
    links: [
      { label: "FAQ", url: "https://www.coolermaster.com/faq/" },
      { label: "MasterHUB Software", url: "https://masterplus.coolermaster.com/" },
    ],
    categories: [],
  },
  {
    id: "corsair",
    name: "Corsair",
    description: "Leading gaming peripherals and components brand.",
    links: [
      { label: "FAQ", url: "https://help.corsair.com/" },
      { label: "Web Hub", url: "https://webdevicemanager.corsair.com/" },
      { label: "Firmware Updater", url: "https://firmware.corsair.com/" },
      { label: "Find Serial Number", url: "https://help.corsair.com/hc/en-us/articles/360033330011" },
    ],
    categories: [
      standardMouseCategory,
      standardKeyboardCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
    ],
  },
  {
    id: "creative",
    name: "Creative",
    description: "Audio and multimedia technology company.",
    links: [],
    categories: [],
  },

  // ── D ──────────────────────────────────────────────────────────────────
  {
    id: "dareu",
    name: "Dareu",
    description: "Gaming peripherals brand for mice and keyboards.",
    links: [
      { label: "FAQ", url: "https://www.dareu.com/pages/faq" },
      { label: "Web Driver", url: "https://web.dareu.com/" },
      { label: "Downloads", url: "https://www.dareu.com/pages/driver" },
    ],
    categories: [standardMouseCategory],
  },
  {
    id: "deltaco-gaming",
    name: "Deltaco Gaming",
    description: "Scandinavian gaming accessories brand.",
    links: [],
    categories: [
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
      standardMouseCategory,
      standardKeyboardCategory,
      standardMousepadCategory,
    ],
  },
  {
    id: "deltahub",
    name: "DeltaHub",
    description: "Ergonomic desk accessories and mousepads.",
    links: [
      { label: "Help Center", url: "https://deltahub.io/pages/help-center" },
    ],
    categories: [],
  },
  {
    id: "ducky",
    name: "Ducky",
    description: "Premium mechanical keyboard manufacturer.",
    links: [
      { label: "Web Driver", url: "https://duckychannel.com.tw/en/software" },
      { label: "Downloads", url: "https://www.duckychannel.com.tw/en/download" },
      { label: "Warranty Info", url: "https://www.duckychannel.com.tw/en/warranty" },
    ],
    categories: [
      {
        name: "Keyboards",
        icon: "Keyboard",
        issues: [
          ...standardKeyboardIssues,
          {
            title: "The F5 key randomly flashes and the keyboard stops working in wireless mode",
            steps: [
              "The F5 indicates connectivity between the keyboard and the dongle. If it starts to flash, it means that the connection was lost.",
              "Please relocate the dongle or keyboard closer to each other and remove other wireless units that might interfere with each other.",
            ],
          },
        ],
      },
    ],
  },
  {
    id: "dxracer",
    name: "DXRacer",
    description: "Gaming chairs and furniture.",
    links: [],
    categories: [],
  },

  // ── E ──────────────────────────────────────────────────────────────────
  {
    id: "elgato",
    name: "Elgato",
    description: "Streaming and content creation equipment.",
    links: [
      { label: "Knowledge Base", url: "https://help.elgato.com/" },
      { label: "Firmware Updates", url: "https://help.elgato.com/hc/en-us/articles/360027963512" },
    ],
    categories: [standardMicrophoneCategory],
  },
  {
    id: "endgame-gear",
    name: "Endgame Gear",
    description: "High-performance gaming mice and accessories.",
    links: [
      { label: "FAQ", url: "https://www.endgamegear.com/faq" },
      { label: "Downloads", url: "https://www.endgamegear.com/downloads" },
    ],
    categories: [standardMouseCategory, standardMousepadCategory, standardMicrophoneCategory],
  },
  {
    id: "esptiger",
    name: "EspTiger",
    description: "Gaming mousepads and accessories.",
    links: [
      { label: "Help", url: "https://www.esptiger.com/pages/help" },
    ],
    categories: [],
  },

  // ── F ──────────────────────────────────────────────────────────────────
  {
    id: "feinmann",
    name: "Feinmann",
    description: "Gaming mice brand (owned by Pulsar).",
    links: [],
    categories: [standardMouseCategory],
  },
  {
    id: "fgg",
    name: "FGG (Fierce Gaming Gear)",
    description: "Gaming peripherals by MadLions.",
    links: [
      { label: "Web Hub", url: "https://connect.fgg.gg/" },
    ],
    categories: [standardMouseCategory, standardKeyboardCategory],
  },
  {
    id: "fifine",
    name: "Fifine",
    description: "Microphones and audio equipment.",
    links: [
      { label: "Manuals & Troubleshooting", url: "https://www.fifinemicrophone.com/pages/support" },
    ],
    categories: [],
  },
  {
    id: "flydigi",
    name: "Flydigi",
    description: "Mobile and PC gaming controllers.",
    links: [
      { label: "FAQ", url: "https://www.flydigi.com/en/faq" },
      { label: "User Manuals", url: "https://www.flydigi.com/en/pdf" },
      { label: "Software", url: "https://www.flydigi.com/en/software" },
    ],
    categories: [standardControllerCategory],
  },

  // ── G ──────────────────────────────────────────────────────────────────
  {
    id: "gamesir",
    name: "GameSir",
    description: "Gaming controllers and mobile gaming accessories.",
    links: [
      { label: "Support", url: "https://www.gamesir.hk/pages/support" },
    ],
    categories: [
      {
        name: "Controllers",
        icon: "Gamepad2",
        issues: [
          {
            title: "The controller is experiencing stick drift",
            steps: [
              "Please try pressurized air to remove potential debris.",
              "If the issue is persistent, please download the respective software for your controller on a PC.",
              "Then use the calibration function to reset the sticks positioning.",
              "If you are still experiencing issues, try to increase the deadzone of the joysticks.",
              "No luck? You're welcome to reach out to our support team.",
            ],
          },
          {
            title: "The triggers register input by themselves / do not register input",
            steps: [
              "Please try pressurized air to remove potential debris.",
              "If the issue is persistent, please download the respective software on a PC.",
              "Then use the calibration function to reset the trigger's positioning.",
              "If you are still experiencing issues, you're welcome to reach out to our support team.",
            ],
          },
          standardControllerIssues[2],
        ],
      },
    ],
  },
  {
    id: "ghostglides",
    name: "GHOSTGLIDES",
    description: "Mouse feet and glide accessories.",
    links: [
      { label: "Application Instructions", url: "https://ghostglides.com/pages/instructions" },
    ],
    categories: [],
  },
  {
    id: "glorious",
    name: "Glorious",
    description: "Gaming peripherals known for mice, keyboards, and accessories.",
    links: [
      { label: "Product Guides", url: "https://www.gloriousgaming.com/pages/product-guides" },
      { label: "How-To Guides", url: "https://www.gloriousgaming.com/pages/how-to-guides" },
      { label: "Glorious Core Software", url: "https://www.gloriousgaming.com/pages/software" },
    ],
    categories: [standardMouseCategory, standardKeyboardCategory],
  },
  {
    id: "google",
    name: "Google",
    description: "Routers and networking equipment.",
    links: [],
    categories: [standardRouterCategory],
  },
  {
    id: "g-wolves",
    name: "G-Wolves",
    description: "Lightweight gaming mice.",
    links: [
      { label: "Drivers", url: "https://www.g-wolves.com/" },
    ],
    categories: [standardMouseCategory],
  },

  // ── H ──────────────────────────────────────────────────────────────────
  {
    id: "haute42",
    name: "Haute42",
    description: "Fighting game controllers and arcade sticks.",
    links: [
      { label: "Support & Firmware", url: "https://www.haute42.com/pages/supports" },
    ],
    categories: [],
  },
  {
    id: "hitscan",
    name: "Hitscan",
    description: "Gaming mice brand.",
    links: [
      { label: "Utility Software", url: "https://hitscan.gg/" },
    ],
    categories: [standardMouseCategory],
  },
  {
    id: "higround",
    name: "Higround",
    description: "Artisan gaming keyboards and mousepads.",
    links: [
      { label: "FAQ", url: "https://higround.co/pages/faq" },
      { label: "Forge App", url: "https://higround.co/pages/forge-app" },
    ],
    categories: [standardMousepadCategory, standardKeyboardCategory],
  },
  {
    id: "hori",
    name: "Hori",
    description: "Licensed gaming accessories and controllers.",
    links: [
      { label: "Firmware Updates", url: "https://stores.horiusa.com/firmware-updates/" },
    ],
    categories: [],
  },
  {
    id: "hyperx",
    name: "HyperX",
    description: "Gaming peripherals including headsets, mice, and keyboards.",
    links: [
      { label: "Support Center", url: "https://hyperx.com/pages/support" },
    ],
    categories: [
      standardMouseCategory,
      standardKeyboardCategory,
      standardMicrophoneCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
    ],
  },

  // ── I ──────────────────────────────────────────────────────────────────
  {
    id: "ipi",
    name: "IPI",
    description: "Keyboard brand.",
    links: [],
    categories: [standardKeyboardCategory],
  },

  // ── K ──────────────────────────────────────────────────────────────────
  {
    id: "keychron",
    name: "Keychron",
    description: "Wireless mechanical keyboards for Mac, Windows, and more.",
    links: [
      { label: "Launcher Software", url: "https://usevia.app/" },
      { label: "User Manuals", url: "https://www.keychron.com/pages/user-manual" },
      { label: "Firmware", url: "https://www.keychron.com/pages/firmware" },
      { label: "Support", url: "https://www.keychron.com/pages/support-center" },
    ],
    categories: [standardKeyboardCategory],
  },
  {
    id: "kiwi-ears",
    name: "Kiwi Ears",
    description: "In-ear monitors and audio products.",
    links: [],
    categories: [standardIEMCategory],
  },

  // ── L ──────────────────────────────────────────────────────────────────
  {
    id: "lamzu",
    name: "Lamzu",
    description: "High-performance gaming mice.",
    links: [
      { label: "FAQ", url: "https://lamzu.com/pages/faq" },
      { label: "Software Download", url: "https://lamzu.com/pages/software" },
      { label: "Web Driver (Mouse)", url: "https://hub.lamzu.com/" },
      { label: "Web Driver (Keyboard)", url: "https://lamzu.net/kb/" },
    ],
    categories: [
      {
        name: "Mice",
        icon: "Mouse",
        issues: [
          {
            title: "Mouse is experiencing scrollwheel issues",
            steps: [
              "Please use pressurized air to remove potential debris and dust.",
              "You can potentially fix the issue by rolling the mouse upside down on a flat surface.",
            ],
          },
          standardMouseCategory.issues[1],
          standardMouseCategory.issues[2],
          {
            title: "Mouse clicks are registering double input",
            steps: [
              "Download the compatible software of your unit and update the firmware.",
              "Please use pressurized air to try and remove potential debris and dust that may interfere with the normal operation of the clicks.",
              "Enter the software and change the debounce time setting to 9ms.",
            ],
          },
          {
            title: "I believe my mouse has sensor issues",
            steps: [
              "Sensor issues are rarely caused by the unit itself, but rather by the environment around it.",
              "Download the compatible software of your unit and update the firmware.",
              "Clean the sensor to remove potential dust and dirt.",
              "Connect your mouse or dongle directly into the motherboard of your PC.",
              "Please try a different USB port and/or cable.",
              "Make sure that the battery of the mouse is not low.",
              "Clear the path between the unit and receiver from other units and items.",
              "Try the unit on a different device to see if the same issue appears.",
              "Some games do not support high polling rates, please try a lower setting.",
            ],
          },
          standardMouseCategory.issues[5],
        ],
      },
    ],
  },
  {
    id: "lanberg",
    name: "Lanberg",
    description: "Computer accessories and networking products.",
    links: [],
    categories: [],
  },
  {
    id: "lethal-gaming-gear",
    name: "Lethal Gaming Gear",
    description: "Gaming mice and mousepads (owned by Pulsar/AplusX).",
    links: [],
    categories: [standardMouseCategory, standardMousepadCategory],
  },
  {
    id: "lofree",
    name: "Lofree",
    description: "Retro-styled mechanical keyboards and mice.",
    links: [
      { label: "Web Driver (Keyboards)", url: "https://hypace.lofree.co/" },
      { label: "Web Driver (Mice)", url: "https://hypace.lofree.co/" },
      { label: "Download Center", url: "https://www.lofree.co/pages/download" },
    ],
    categories: [standardKeyboardCategory],
  },
  {
    id: "logitech",
    name: "Logitech",
    description: "World-leading computer peripherals and gaming brand.",
    links: [
      { label: "Gaming FAQ & Downloads", url: "https://support.logi.com/hc/en-us/categories/360001702893" },
    ],
    categories: [
      standardMouseCategory,
      standardKeyboardCategory,
      standardMousepadCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
      standardMicrophoneCategory,
    ],
  },
  {
    id: "luminkey",
    name: "Luminkey",
    description: "Custom mechanical keyboards.",
    links: [
      { label: "User Guides & Firmware", url: "https://www.luminkey.com/pages/user-guide" },
      { label: "Web Driver", url: "https://www.luminkey.com/" },
    ],
    categories: [standardKeyboardCategory],
  },

  // ── M ──────────────────────────────────────────────────────────────────
  {
    id: "manba",
    name: "Manba",
    description: "Budget gaming controllers.",
    links: [
      { label: "User Guide / FAQ", url: "https://www.manbagaming.com/pages/user-guide" },
    ],
    categories: [standardControllerCategory],
  },
  {
    id: "maono",
    name: "Maono",
    description: "Microphones and audio equipment.",
    links: [
      { label: "Help Center", url: "https://help.maono.com/" },
      { label: "Software", url: "https://help.maono.com/hc/en-us/sections/software" },
    ],
    categories: [standardMicrophoneCategory],
  },
  {
    id: "maxmount",
    name: "MaxMount",
    description: "Monitor mounts and desk accessories.",
    links: [],
    categories: [],
    contactInfo: "If you're experiencing any issues with a MaxMount product, you're welcome to contact our support team. Please take your time to in detail explain the issue and provide pictures and videos of the issue for a faster and easier resolution.",
  },
  {
    id: "mchose",
    name: "MCHOSE",
    description: "Gaming mice and keyboards.",
    links: [
      { label: "Firmware & Web Driver", url: "https://www.mchose.com/pages/firmware" },
      { label: "User Manual", url: "https://www.mchose.com/pages/user-manual" },
    ],
    categories: [
      standardMouseCategory,
      standardKeyboardCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
    ],
  },
  {
    id: "meletrix",
    name: "Meletrix",
    description: "Custom mechanical keyboards.",
    links: [],
    categories: [
      {
        name: "Keyboards",
        icon: "Keyboard",
        issues: [
          ...standardKeyboardIssues,
          {
            title: "Power issues (possible daughterboard defect)",
            steps: [
              "Possibly a defective daughterboard (or belonging cords).",
              "Please film a video of the issue and contact our technical support, we will provide further instructions.",
            ],
          },
          {
            title: "Interactive screen does not work",
            steps: [
              "Make sure that the screen is turned on (please see the product manual for instructions).",
              "Open the case and make sure that the FFC Ribbon cable is mounted correctly.",
              "If the Ribbon is damaged, please reach out to our technical support.",
            ],
          },
          {
            title: "Changes in software aren't saved",
            steps: [
              "Please make sure that you click the 'Sync' button after any changes to the settings of the keyboard.",
            ],
          },
        ],
      },
    ],
    contactInfo: "For the smoothest resolution, please contact Meletrix directly. Their specialists will be able to help with troubleshooting, replacement or equal solutions.",
  },
  {
    id: "melody-wings",
    name: "Melody Wings",
    description: "In-ear monitors and earphones.",
    links: [],
    categories: [standardIEMCategory],
  },
  {
    id: "microsoft-xbox",
    name: "Microsoft / Xbox",
    description: "Xbox controllers and gaming accessories.",
    links: [
      { label: "Register Product", url: "https://account.microsoft.com/devices/" },
    ],
    categories: [
      {
        name: "Controllers",
        icon: "Gamepad2",
        issues: [
          {
            title: "The controller is experiencing stick drift",
            steps: [
              "Make sure that your controller has the latest firmware.",
              "Please try pressurized air to remove potential debris.",
              "Enter the Xbox Accessories App and follow the guide to recalibrate your sticks.",
              "No luck? You're welcome to reach out to our support team.",
            ],
          },
          {
            title: "The triggers register input by themselves / do not register input",
            steps: [
              "Make sure that your controller has the latest firmware.",
              "Please try pressurized air to remove potential debris.",
              "Enter the Xbox Accessories App and follow the guide to recalibrate your triggers.",
              "If you are still experiencing issues, you're welcome to reach out to our support team.",
            ],
          },
          {
            title: "The controller does not charge",
            steps: [
              "Make sure that your controller has the latest firmware.",
              "Please check the USB-C port for potential dust that may prohibit the device charging correctly.",
              "If the issue persists, try another cable, adapter and power outlet to eliminate accessories as the cause.",
              "Is the controller still experiencing issues? Please reach out to our support team.",
            ],
          },
        ],
      },
    ],
    contactInfo: "To update your firmware, calibrate sticks/triggers and keep track of your units, please download the Xbox Accessories App.",
  },
  {
    id: "moondrop",
    name: "Moondrop",
    description: "High-fidelity in-ear monitors and audio equipment.",
    links: [
      { label: "Manual Guide", url: "https://www.moondroplab.com/en/manual-guide" },
      { label: "Downloads", url: "https://www.moondroplab.com/en/download" },
    ],
    categories: [standardIEMCategory],
  },
  {
    id: "moza-racing",
    name: "Moza Racing",
    description: "Sim racing wheels, pedals, and accessories.",
    links: [
      { label: "Compatibility Guide", url: "https://www.mozaracing.com/support" },
      { label: "Knowledge Base", url: "https://www.mozaracing.com/support" },
    ],
    categories: [],
  },

  // ── N ──────────────────────────────────────────────────────────────────
  {
    id: "ninjutso",
    name: "Ninjutso",
    description: "Lightweight gaming mice.",
    links: [
      { label: "Web Driver", url: "https://hub.ninjutso.com/" },
      { label: "Software/Firmware", url: "https://www.ninjutso.com/pages/download" },
    ],
    categories: [standardMouseCategory],
  },
  {
    id: "nintendo",
    name: "Nintendo",
    description: "Gaming consoles and accessories.",
    links: [],
    categories: [],
  },
  {
    id: "nothing",
    name: "Nothing",
    description: "Consumer electronics and earphones.",
    links: [
      { label: "Support Centre", url: "https://nothing.tech/pages/support" },
      { label: "Product Guide", url: "https://nothing.tech/pages/product-guide" },
      { label: "Troubleshooting", url: "https://nothing.tech/pages/troubleshooting" },
      { label: "FAQ", url: "https://nothing.tech/pages/faq" },
    ],
    categories: [],
  },
  {
    id: "nuphy",
    name: "NuPhy",
    description: "Compact mechanical keyboards.",
    links: [],
    categories: [standardKeyboardCategory],
  },

  // ── O ──────────────────────────────────────────────────────────────────
  {
    id: "orbital-works",
    name: "Orbital Works",
    description: "Gaming mice.",
    links: [
      { label: "Software/Firmware", url: "https://orbitalworks.co/pages/download" },
    ],
    categories: [
      {
        name: "Mice",
        icon: "Mouse",
        issues: [
          {
            title: "Mouse is experiencing scrollwheel issues",
            steps: [
              "Please use pressurized air to try and remove potential debris and dust that may interfere with the normal operation of the scrollwheel.",
            ],
          },
          standardMouseCategory.issues[1],
          standardMouseCategory.issues[2],
          {
            title: "Mouse clicks are registering double input",
            steps: [
              "Install the latest firmware. Download from https://orbitalworks.co/pages/download.",
              "Please use pressurized air to try and remove potential debris and dust that may interfere with the normal operation of the clicks.",
              "Download the software and change the debounce time setting to 9ms.",
            ],
          },
          standardMouseCategory.issues[4],
          standardMouseCategory.issues[5],
        ],
      },
    ],
  },

  // ── P ──────────────────────────────────────────────────────────────────
  {
    id: "pdp",
    name: "PDP",
    description: "Gaming controllers and accessories.",
    links: [],
    categories: [],
  },
  {
    id: "philips",
    name: "Philips",
    description: "Electronics and displays.",
    links: [],
    categories: [standardScreenCategory],
  },
  {
    id: "pulsar",
    name: "Pulsar",
    description: "Gaming mice, mousepads, and accessories.",
    links: [
      { label: "Support Center", url: "https://www.pulsar.gg/pages/support" },
      { label: "Downloads", url: "https://www.pulsar.gg/pages/download" },
      { label: "Web Driver", url: "https://bibimbap.pulsar.gg/" },
    ],
    categories: [standardMouseCategory, standardMousepadCategory],
  },
  {
    id: "pwnage",
    name: "Pwnage",
    description: "Custom gaming mice.",
    links: [
      { label: "FAQ/Support", url: "https://pwnage.com/pages/support" },
      { label: "Web Driver", url: "https://pwnage.com/pages/drivers-hub" },
      { label: "Drivers", url: "https://pwnage.com/pages/drivers" },
    ],
    categories: [standardMouseCategory],
  },
  {
    id: "pxn",
    name: "PXN",
    description: "Gaming controllers and racing wheels.",
    links: [],
    categories: [],
  },

  // ── R ──────────────────────────────────────────────────────────────────
  {
    id: "rawm",
    name: "RAWM",
    description: "Gaming mice.",
    links: [],
    categories: [
      {
        name: "Mice",
        icon: "Mouse",
        issues: [
          {
            title: "The mouse does not connect to the receiver",
            steps: [
              "Please download the Rawm Hub App.",
              "Connect both the mouse and the receiver to the computer using 2 cables.",
              "An icon will appear under the image of the mouse. Please click it.",
              "The mouse should now be paired to the dongle.",
            ],
          },
          ...standardMouseCategory.issues,
        ],
      },
    ],
  },
  {
    id: "razer",
    name: "Razer",
    description: "Premier gaming peripherals and lifestyle brand.",
    links: [
      { label: "Mouse Support", url: "https://mysupport.razer.com/" },
      { label: "Find Serial Number", url: "https://mysupport.razer.com/app/answers/detail/a_id/548/" },
    ],
    categories: [
      standardMouseCategory,
      standardKeyboardCategory,
      standardMousepadCategory,
      standardMicrophoneCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
    ],
  },

  // ── S ──────────────────────────────────────────────────────────────────
  {
    id: "satechi",
    name: "Satechi",
    description: "Premium tech accessories.",
    links: [],
    categories: [],
  },
  {
    id: "scuf",
    name: "Scuf",
    description: "High-performance gaming controllers.",
    links: [
      { label: "Product Manuals", url: "https://customercare.scufgaming.com/hc/en-us/articles/9615810126477" },
    ],
    categories: [
      {
        name: "Controllers (Envision)",
        icon: "Gamepad2",
        issues: [
          {
            title: "The controller does not work correctly",
            steps: [
              "You need to install the iCUE software on your PC to update the unit to the latest firmware.",
              "In the software, you'll be able to calibrate sticks and triggers, and set preferences for the usage of the unit.",
            ],
          },
          {
            title: "The controller is experiencing stick drift",
            steps: [
              "Please try pressurized air to remove potential debris.",
              "If the issue is persistent, please download the iCUE software on a PC.",
              "Then use the calibration function to reset the sticks positioning.",
              "If you are still experiencing issues, try to increase the deadzone of the joysticks.",
              "No luck? You're welcome to reach out to our support team.",
            ],
          },
          {
            title: "The triggers register input by themselves / do not register input",
            steps: [
              "Please try pressurized air to remove potential debris.",
              "If the issue is persistent, please download the iCUE software on a PC.",
              "Then use the calibration function to reset the trigger's positioning.",
              "If you are still experiencing issues, you're welcome to reach out to our support team.",
            ],
          },
          standardControllerIssues[2],
        ],
      },
      {
        name: "Controllers (Valor Wireless)",
        icon: "Gamepad2",
        issues: [
          {
            title: "The controller does not work correctly",
            steps: [
              "You need to install the Valor Pro companion app on your PC to update the unit to the latest firmware.",
              "In the software, you'll be able to calibrate sticks and triggers, and set preferences for the usage of the unit.",
            ],
          },
          {
            title: "The controller is experiencing stick drift",
            steps: [
              "Please try pressurized air to remove potential debris.",
              "If the issue is persistent, please download the Valor Pro companion app on a PC.",
              "Then use the calibration function to reset the sticks positioning.",
              "No luck? You're welcome to reach out to our support team.",
            ],
          },
          {
            title: "The triggers register input by themselves / do not register input",
            steps: [
              "Please try pressurized air to remove potential debris.",
              "If the issue is persistent, please download the Valor Pro companion app on a PC.",
              "Then use the calibration function to reset the trigger's positioning.",
              "If you are still experiencing issues, you're welcome to reach out to our support team.",
            ],
          },
          standardControllerIssues[2],
        ],
      },
    ],
  },
  {
    id: "scyrox",
    name: "Scyrox",
    description: "Gaming mice by Lamzu.",
    links: [],
    categories: [standardMouseCategory],
  },
  {
    id: "shure",
    name: "Shure",
    description: "Professional microphones and audio equipment.",
    links: [
      { label: "User Guides", url: "https://www.shure.com/en-US/search?filters%5B0%5D%5Bfield%5D=group&filters%5B0%5D%5Bvalues%5D%5B0%5D=Documents" },
      { label: "Knowledge Base", url: "https://service.shure.com/" },
      { label: "Find Serial Number", url: "https://service.shure.com/s/article/Where-do-I-find-the-Serial-Number" },
    ],
    categories: [
      {
        name: "Microphones",
        icon: "Mic",
        issues: [
          {
            title: "My microphone does not power on",
            steps: [
              "Please try a different cable and PC USB port to rule out accessories error.",
              "Make sure that the USB-C port on the unit isn't blocked by dirt or debris.",
            ],
          },
          {
            title: "Microphone is powered on but not recognized by the computer",
            steps: [
              "Please try a different cable and PC USB port to rule out accessories error.",
              "Make sure that you have the latest version of the software.",
              "Please restart your system, as it might help configure the device.",
            ],
          },
          {
            title: "Microphone is recognized but does not record sound",
            steps: [
              "Make sure that your unit is chosen as the audio input device on your PC.",
              "Make sure that any physical mute buttons aren't activated.",
              "Enter the product's software and make sure no settings cause the issues.",
              "Please perform a firmware update (can be found on the manufacturer's website).",
            ],
          },
          {
            title: "Microphone records sound but quality is not as expected",
            steps: [
              "Please make sure that all external factors are optimal. Reduce or remove surrounding sound and place the microphone closer to the source.",
              "Enter the product software and play around with some audio settings.",
              "Please try to differentiate between expected quality and defective quality.",
            ],
          },
          {
            title: "My microphone disconnects randomly",
            steps: [
              "Make sure that no unwanted power settings are activated in the software.",
              "Please try another cord and power source to rule out accessories error.",
              "Make sure that the USB-C port on the unit isn't blocked by dirt or debris.",
            ],
          },
        ],
      },
    ],
  },
  {
    id: "skullcandy",
    name: "Skullcandy",
    description: "Headphones and audio accessories.",
    links: [],
    categories: [],
  },
  {
    id: "steelseries",
    name: "SteelSeries",
    description: "Premium gaming peripherals including mice, keyboards, and headsets.",
    links: [],
    categories: [
      standardMouseCategory,
      standardKeyboardCategory,
      standardMousepadCategory,
      standardMicrophoneCategory,
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
    ],
  },

  // ── T ──────────────────────────────────────────────────────────────────
  {
    id: "teevolution",
    name: "Teevolution",
    description: "Gaming mice.",
    links: [
      { label: "Downloads", url: "https://teevolution.com/pages/download" },
      { label: "Web Driver", url: "https://teevolink.com/" },
    ],
    categories: [standardMouseCategory],
  },
  {
    id: "tp-link",
    name: "TP-Link",
    description: "Routers, networking, and smart home cameras.",
    links: [],
    categories: [standardRouterCategory, standardCameraCategory],
  },
  {
    id: "trust",
    name: "Trust",
    description: "Computer peripherals and accessories.",
    links: [
      { label: "Support", url: "https://www.trust.com/en/support" },
    ],
    categories: [standardMousepadCategory],
  },
  {
    id: "truthear",
    name: "Truthear",
    description: "High-fidelity in-ear monitors.",
    links: [
      { label: "Downloads (DAC/AMP)", url: "https://www.truthear.com/pages/download" },
    ],
    categories: [standardIEMCategory],
  },
  {
    id: "turtle-beach",
    name: "Turtle Beach",
    description: "Gaming headsets, mousepads, and accessories.",
    links: [
      { label: "User Guides & Troubleshooting", url: "https://support.turtlebeach.com/" },
      { label: "Downloads", url: "https://www.turtlebeach.com/pages/downloads" },
    ],
    categories: [
      standardWirelessHeadphoneCategory,
      standardWiredHeadphoneCategory,
      standardMousepadCategory,
    ],
  },
  {
    id: "twisted-minds",
    name: "Twisted Minds",
    description: "Gaming monitors.",
    links: [],
    categories: [standardScreenCategory],
  },

  // ── V ──────────────────────────────────────────────────────────────────
  {
    id: "varmilo",
    name: "Varmilo",
    description: "Premium mechanical keyboards with artistic designs.",
    links: [
      { label: "Manuals, Drivers & Firmware", url: "https://en.varmilo.com/keyboardprosc498/category-proscript78" },
      { label: "Web Driver", url: "https://en.varmilo.com/" },
    ],
    categories: [standardKeyboardCategory, standardMousepadCategory],
  },

  // ── W ──────────────────────────────────────────────────────────────────
  {
    id: "waizowl",
    name: "Waizowl",
    description: "Gaming mice.",
    links: [
      { label: "Downloads", url: "https://www.waizowl.com/pages/download" },
      { label: "Instructions", url: "https://www.waizowl.com/pages/instructions" },
    ],
    categories: [standardMouseCategory],
  },
  {
    id: "wlmouse",
    name: "WLMouse",
    description: "High-performance gaming mice and keyboards.",
    links: [
      { label: "Mouse Web Driver", url: "https://hub.wlmouse.com/" },
      { label: "Keyboard Software", url: "https://www.wlmouse.com/en-wl/pages/download" },
    ],
    categories: [
      standardMouseCategory,
      {
        name: "Keyboards",
        icon: "Keyboard",
        issues: [
          {
            title: "Keyboard experiencing issues",
            steps: [
              "Go to the manufacturer's website and enter their online software for the specific product.",
              "Go to the settings and perform a firmware update, either by their online tool or downloading the firmware.",
              "If the issue persists, please reach out to our support team.",
            ],
          },
        ],
      },
    ],
  },
  {
    id: "wooting",
    name: "Wooting",
    description: "Analog mechanical keyboards with rapid trigger technology.",
    links: [
      { label: "Quickstart Guides", url: "https://wooting.io/quickstart" },
      { label: "Troubleshooting", url: "https://help.wooting.io/" },
      { label: "FAQ", url: "https://help.wooting.io/" },
    ],
    categories: [standardKeyboardCategory],
  },
  {
    id: "wuque-studio",
    name: "Wuque Studio",
    description: "Custom mechanical keyboards (Meletrix).",
    links: [
      { label: "User Manuals", url: "https://shop.wuquestudio.com/pages/user-manual" },
      { label: "Firmware", url: "https://shop.wuquestudio.com/pages/firmwares" },
      { label: "Knowledge Base", url: "https://shop.wuquestudio.com/pages/resource-library" },
    ],
    categories: [
      {
        name: "Keyboards",
        icon: "Keyboard",
        issues: [
          ...standardKeyboardIssues,
          {
            title: "Power issues (possible daughterboard defect)",
            steps: [
              "Possibly a defective daughterboard (or belonging cords).",
              "Please film a video of the issue and contact our technical support, we will provide further instructions.",
            ],
          },
          {
            title: "Interactive screen does not work",
            steps: [
              "Make sure that the screen is turned on (please see the product manual for instructions).",
              "Open the case and make sure that the FFC Ribbon cable is mounted correctly.",
              "If the Ribbon is damaged, please reach out to our technical support.",
            ],
          },
          {
            title: "Changes in software aren't saved",
            steps: [
              "Please make sure that you click the 'Sync' button after any changes to the settings of the keyboard.",
            ],
          },
        ],
      },
    ],
    contactInfo: "For the smoothest resolution, please contact Wuque directly. Their specialists will be able to help with troubleshooting, replacement or equal solutions.",
  },

  // ── X ──────────────────────────────────────────────────────────────────
  {
    id: "xiaomi",
    name: "Xiaomi",
    description: "Consumer electronics and smart devices.",
    links: [
      { label: "User Guide", url: "https://www.mi.com/global/support/user-guide" },
    ],
    categories: [standardScreenCategory],
  },

  // ── 8 ──────────────────────────────────────────────────────────────────
  {
    id: "8bitdo",
    name: "8BitDo",
    description: "Retro-styled gaming controllers.",
    links: [
      { label: "Support (Firmware & Manuals)", url: "https://support.8bitdo.com/" },
    ],
    categories: [
      {
        name: "Controllers",
        icon: "Gamepad2",
        issues: [
          {
            title: "The controller is experiencing stick drift",
            steps: [
              "Make sure that your controller has the latest firmware.",
              "Please try pressurized air to remove potential debris.",
              "No luck? You're welcome to reach out to our support team.",
            ],
          },
          {
            title: "The triggers register input by themselves / do not register input",
            steps: [
              "Make sure that your controller has the latest firmware.",
              "Please try pressurized air to remove potential debris.",
              "If you are still experiencing issues, you're welcome to reach out to our support team.",
            ],
          },
          {
            title: "The controller does not charge",
            steps: [
              "Make sure that your controller has the latest firmware.",
              "Please check the USB-C port for potential dust that may prohibit the device charging correctly.",
              "If the issue persists, try another cable, adapter and power outlet to eliminate accessories as the cause.",
              "Is the controller still experiencing issues? Please reach out to our support team.",
            ],
          },
        ],
      },
    ],
  },
];

export function getBrandById(id: string): Brand | undefined {
  return brands.find((b) => b.id === id);
}

export function searchBrands(query: string): Brand[] {
  const q = query.toLowerCase().trim();
  if (!q) return brands;
  return brands.filter((brand) => {
    if (brand.name.toLowerCase().includes(q)) return true;
    if (brand.description?.toLowerCase().includes(q)) return true;
    for (const cat of brand.categories) {
      if (cat.name.toLowerCase().includes(q)) return true;
      for (const issue of cat.issues) {
        if (issue.title.toLowerCase().includes(q)) return true;
        for (const step of issue.steps) {
          if (step.toLowerCase().includes(q)) return true;
        }
      }
    }
    return false;
  });
}

export interface SearchResult {
  brand: Brand;
  matchedCategory?: string;
  matchedIssue?: string;
}

export function deepSearch(query: string): SearchResult[] {
  const q = query.toLowerCase().trim();
  if (!q) return brands.map((b) => ({ brand: b }));
  const results: SearchResult[] = [];
  for (const brand of brands) {
    if (brand.name.toLowerCase().includes(q)) {
      results.push({ brand });
      continue;
    }
    let found = false;
    for (const cat of brand.categories) {
      if (found) break;
      for (const issue of cat.issues) {
        if (
          issue.title.toLowerCase().includes(q) ||
          issue.steps.some((s) => s.toLowerCase().includes(q))
        ) {
          results.push({ brand, matchedCategory: cat.name, matchedIssue: issue.title });
          found = true;
          break;
        }
      }
      if (!found && cat.name.toLowerCase().includes(q)) {
        results.push({ brand, matchedCategory: cat.name });
        found = true;
      }
    }
    if (!found && brand.description?.toLowerCase().includes(q)) {
      results.push({ brand });
    }
  }
  return results;
}
