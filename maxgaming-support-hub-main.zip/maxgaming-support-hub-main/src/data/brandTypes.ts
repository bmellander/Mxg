export interface TroubleshootingIssue {
  title: string;
  steps: string[];
}

export interface ProductCategory {
  name: string;
  icon: string; // lucide icon name
  issues: TroubleshootingIssue[];
}

export interface BrandLink {
  label: string;
  url: string;
}

export interface Brand {
  id: string;
  name: string;
  description?: string;
  links: BrandLink[];
  categories: ProductCategory[];
  contactInfo?: string;
  directToManufacturer?: boolean;
  manufacturerUrl?: string;
}
