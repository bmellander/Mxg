import { useParams, Link } from "react-router-dom";
import { getBrandById } from "@/data/brands";
import Header from "@/components/Header";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import {
  ArrowLeft,
  ExternalLink,
  AlertTriangle,
  Mouse,
  Keyboard,
  Headphones,
  Gamepad2,
  Mic,
  RectangleHorizontal,
  Monitor,
  Package,
} from "lucide-react";

const iconMap: Record<string, React.ReactNode> = {
  Mouse: <Mouse className="h-5 w-5" />,
  Keyboard: <Keyboard className="h-5 w-5" />,
  Headphones: <Headphones className="h-5 w-5" />,
  Gamepad2: <Gamepad2 className="h-5 w-5" />,
  Mic: <Mic className="h-5 w-5" />,
  RectangleHorizontal: <RectangleHorizontal className="h-5 w-5" />,
  Monitor: <Monitor className="h-5 w-5" />,
  Package: <Package className="h-5 w-5" />,
};

const BrandPage = () => {
  const { brandId } = useParams<{ brandId: string }>();
  const brand = getBrandById(brandId || "");

  if (!brand) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20 text-center">
          <h1 className="font-display text-3xl font-bold text-foreground">Brand not found</h1>
          <p className="mt-2 text-muted-foreground">
            The brand you're looking for doesn't exist.
          </p>
          <Link
            to="/"
            className="mt-6 inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to all brands
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-6 md:py-10">
        {/* Breadcrumb */}
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-colors mb-6"
        >
          <ArrowLeft className="h-4 w-4" />
          All brands
        </Link>

        {/* Brand header */}
        <div className="mb-8">
          <h1 className="font-display text-3xl md:text-4xl font-bold text-foreground">
            {brand.name}
          </h1>
          {brand.description && (
            <p className="mt-2 text-lg text-muted-foreground">{brand.description}</p>
          )}

          {/* Quick links */}
          {brand.links.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {brand.links.map((link) => (
                <a
                  key={link.url}
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-md border border-border bg-secondary/50 px-3 py-1.5 text-sm text-secondary-foreground hover:bg-secondary hover:border-primary/30 transition-all"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  {link.label}
                </a>
              ))}
            </div>
          )}
        </div>

        {/* Direct to manufacturer notice */}
        {brand.directToManufacturer && (
          <div className="mb-8 rounded-lg border border-primary/30 bg-primary/5 p-5">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <h3 className="font-display font-semibold text-foreground">
                  Direct manufacturer support recommended
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  {brand.contactInfo}
                </p>
                {brand.manufacturerUrl && (
                  <a
                    href={brand.manufacturerUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-3 inline-flex items-center gap-1.5 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
                  >
                    <ExternalLink className="h-4 w-4" />
                    Register your claim
                  </a>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Product categories */}
        {brand.categories.length > 0 && (
          <div className="space-y-6">
            {brand.categories.map((category) => (
              <div key={category.name} className="rounded-lg border border-border bg-card overflow-hidden">
                <div className="flex items-center gap-3 border-b border-border bg-secondary/30 px-5 py-4">
                  <span className="text-primary">
                    {iconMap[category.icon] || <Package className="h-5 w-5" />}
                  </span>
                  <h2 className="font-display text-xl font-semibold text-foreground">
                    {category.name}
                  </h2>
                  <span className="ml-auto rounded-full bg-secondary px-2.5 py-0.5 text-xs text-muted-foreground">
                    {category.issues.length} issue{category.issues.length !== 1 ? "s" : ""}
                  </span>
                </div>

                <Accordion type="multiple" className="px-2">
                  {category.issues.map((issue, idx) => (
                    <AccordionItem key={idx} value={`${category.name}-${idx}`} className="border-border">
                      <AccordionTrigger className="px-3 py-3 text-sm font-medium text-foreground hover:text-primary hover:no-underline transition-colors">
                        {issue.title}
                      </AccordionTrigger>
                      <AccordionContent className="px-3 pb-4">
                        <ol className="space-y-2">
                          {issue.steps.map((step, stepIdx) => (
                            <li
                              key={stepIdx}
                              className="flex gap-3 text-sm text-muted-foreground"
                            >
                              <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 text-xs font-medium text-primary">
                                {stepIdx + 1}
                              </span>
                              <span>{step}</span>
                            </li>
                          ))}
                        </ol>
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </div>
            ))}
          </div>
        )}

        {/* No categories */}
        {brand.categories.length === 0 && !brand.directToManufacturer && (
          <div className="rounded-lg border border-border bg-card p-8 text-center">
            <Package className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <h3 className="font-display text-lg font-semibold text-foreground">
              Troubleshooting info coming soon
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Detailed troubleshooting steps for {brand.name} products will be added shortly.
            </p>
          </div>
        )}

        {/* Contact support */}
        <div className="mt-10 rounded-lg border border-border bg-card p-6">
          <h3 className="font-display text-lg font-semibold text-foreground">
            Still need help?
          </h3>
          <p className="mt-1 text-sm text-muted-foreground">
            If the troubleshooting steps above didn't resolve your issue, please contact MaxGaming support.
            Make sure to include your order number, product name, and a description of the issue. Photos or videos of the defect are always helpful.
          </p>
          {brand.contactInfo && !brand.directToManufacturer && (
            <p className="mt-3 text-sm text-primary">{brand.contactInfo}</p>
          )}
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-10">
        <div className="container text-center text-sm text-muted-foreground">
          <p>MaxGaming RMA Support Center — Troubleshoot before you ship</p>
        </div>
      </footer>
    </div>
  );
};

export default BrandPage;
