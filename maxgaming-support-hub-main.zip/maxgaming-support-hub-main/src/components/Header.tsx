import { Link } from "react-router-dom";
import { Search } from "lucide-react";

const Header = () => {
  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center">
            <span className="font-display font-bold text-primary-foreground text-lg">M</span>
          </div>
          <div>
            <span className="font-display font-bold text-xl tracking-tight text-foreground">
              Max<span className="text-gradient-primary">Gaming</span>
            </span>
            <span className="hidden sm:inline ml-2 text-sm text-muted-foreground font-sans">
              RMA Support
            </span>
          </div>
        </Link>
        <Link
          to="/"
          className="flex items-center gap-2 rounded-lg border border-border bg-secondary/50 px-3 py-1.5 text-sm text-muted-foreground hover:bg-secondary transition-colors"
        >
          <Search className="h-4 w-4" />
          <span className="hidden sm:inline">Search brands...</span>
        </Link>
      </div>
    </header>
  );
};

export default Header;
