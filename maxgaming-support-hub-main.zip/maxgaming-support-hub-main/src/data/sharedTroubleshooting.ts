import { TroubleshootingIssue, ProductCategory } from "./brandTypes";

// ─── MICE ───────────────────────────────────────────────────────────────

export const standardMouseIssues: TroubleshootingIssue[] = [
  {
    title: "Mouse is experiencing scrollwheel issues",
    steps: [
      "Please use pressurized air to try and remove potential debris and dust that may interfere with the normal operation of the scrollwheel.",
      "If you're still experiencing issues, please reach out to our support team.",
    ],
  },
  {
    title: "Mouse clicks are looser than expected",
    steps: [
      "The feel to a mouse click may vary between different brands, models and even units within the same batches.",
      "In many cases, this is not considered a defect. However, if the difference affects functionality during normal use, please reach out to our support team.",
    ],
  },
  {
    title: "Mouse clicks experience pre-travel",
    steps: [
      "If the clicks have a clear pre-travel, please contact our support team for evaluation. We will assist you with how to proceed.",
    ],
  },
  {
    title: "Mouse clicks are registering double input",
    steps: [
      "Please use pressurized air to try and remove potential debris and dust that may interfere with the normal operation of the clicks.",
      "Check if your software allows you to change the debounce time setting. For normal function, this setting should be set to 9ms.",
      "If your unit still experiences issues, please reach out to our support team.",
    ],
  },
  {
    title: "I believe my mouse has sensor issues",
    steps: [
      "Sensor issues are rarely caused by the unit itself, but rather by the environment around it.",
      "Update the firmware of your unit.",
      "Clean the sensor to remove potential dust and dirt.",
      "Connect your mouse or dongle directly into the motherboard of your PC.",
      "Please try a different USB port and/or cable.",
      "Make sure that the battery of the mouse is not low.",
      "Clear the path between the unit and receiver from other units and items.",
      "Try the unit on a different device to see if the same issue appears.",
      "Some games do not support high polling rates, please try a lower setting.",
    ],
  },
  {
    title: "Mouse produces sounds that I don't like",
    steps: [
      "Sound in clicks and scrolling wheels may differ between models and even batches of units.",
      "Generally, sound is included in the term 'cosmetic issue', which is typically not covered by the warranty.",
      "Claims will need to be reviewed and decided on a case-by-case basis.",
    ],
  },
];

export const standardMouseCategory: ProductCategory = {
  name: "Mice",
  icon: "Mouse",
  issues: standardMouseIssues,
};

// ─── MOUSEPADS ──────────────────────────────────────────────────────────

export const standardMousepadIssues: TroubleshootingIssue[] = [
  {
    title: "My mousepad has stitch imperfections",
    steps: [
      "Minor stitch fraying or finish differences are not considered a defect.",
      "If the imperfection directly impacts functionality or user experience, please reach out to us.",
    ],
  },
  {
    title: "My mousepad has traction differences",
    steps: [
      "Mousepads are built to last long given that they are treated with care.",
      "Make sure to clean the mousepad following manufacturer's instructions to increase life expectancy.",
      "If you're experiencing issues even with a clean surface, please register a claim. Since mousepads are subject to wear and tear, we will look at the claim on a case-by-case basis.",
    ],
  },
  {
    title: "My mousepad does not lay flat",
    steps: [
      "Please try to add weight to the affected area during a prolonged time (for example stacked books).",
      "If this does not help to flatten the mousepad, please create a claim.",
    ],
  },
  {
    title: "The mousepad's upper layer has started to release from the rubber bottom",
    steps: [
      "Please register a claim given that no physical damage has been dealt to the product.",
    ],
  },
];

export const standardMousepadCategory: ProductCategory = {
  name: "Mousepads",
  icon: "RectangleHorizontal",
  issues: standardMousepadIssues,
};

// ─── KEYBOARDS ──────────────────────────────────────────────────────────

export const standardKeyboardIssues: TroubleshootingIssue[] = [
  {
    title: "Power issues (power cuts out / does not start / loose USB-C port)",
    steps: [
      "Always begin with a potential firmware update to ensure normal functionality.",
      "Try a different USB port on your computer, preferably directly into the motherboard.",
      "Try a different cable to rule out accessory error.",
      "Please check the USB-C port on the keyboard for potential debris or dust, as this has to be safely removed for normal function.",
    ],
  },
  {
    title: "Key issues – My keyboard is not hot-swappable",
    steps: [
      "You can try to use pressurized air to remove potential dust and debris that might affect the functionality of the switch.",
      "If it does not work, please take a video of the issue and forward it to our support team in your claim. We appreciate if the serial number is visible in the same video for smoother handling.",
    ],
  },
  {
    title: "Key issues – My keyboard is hot-swappable",
    steps: [
      "Use a keycap puller and switch remover tool to remove the affected key.",
      "Please apply a new switch to see if this solves the problem. If you do not have extra switches, please loan one from a functioning key just for troubleshooting.",
      "If a new switch solves the issue, please reach out to our support team and we will send a new one. If it did not work, please take a video of the issue and proceed with sending the whole keyboard to us.",
    ],
  },
  {
    title: "When I connect the keyboard, a USB error occurs on my PC",
    steps: [
      "Connect the keyboard directly into a different USB port into the motherboard.",
      "Try a different cable.",
      "Restart your computer.",
      "If possible, perform a firmware update.",
    ],
  },
  {
    title: "RGB does not work on one or multiple keys",
    steps: [
      "Please enter the product's software (if one is offered) and reset the keyboard. This should also be possible manually, please check the provided manual for instructions.",
      "Perform a firmware update if one is available.",
      "Some models have key combinations that turn off or change color on certain keys. For these models, please see a provided manual for further instructions.",
    ],
  },
  {
    title: "I experience input lag",
    steps: [
      "Please update your unit to the latest firmware.",
      "If you're using the keyboard wireless, make sure that the battery is charged and that the receiver is close to your unit.",
      "Close unnecessary programs and/or restart your computer.",
    ],
  },
  {
    title: "My keyboard registers input by itself",
    steps: [
      "Please update your unit to the latest firmware.",
      "Please clean the affected keys and if your keyboard is hotswappable, swap the switches.",
    ],
  },
  {
    title: "My function keys (F1-F12) do not work",
    steps: [
      "You may have accidentally activated Fn Lock. The usual solution is to press Esc+Fn, but please see the product manual for exact instructions.",
    ],
  },
  {
    title: "My numberpad does not work",
    steps: [
      "You may have accidentally activated NumLock. Please press the NumLock button to activate the numberpad again.",
    ],
  },
];

export const standardKeyboardCategory: ProductCategory = {
  name: "Keyboards",
  icon: "Keyboard",
  issues: standardKeyboardIssues,
};

// ─── IEMs / EARPHONES ───────────────────────────────────────────────────

export const standardIEMIssues: TroubleshootingIssue[] = [
  {
    title: "The earbuds play no audio",
    steps: [
      "Please try the headphones on a different device.",
      "If they don't work, please check that the pins in the earbuds are inserted correctly.",
    ],
  },
  {
    title: "There's a lower sound in one of the earbuds",
    steps: [
      "Please try the headphones on a different device.",
      "Please swap the earbuds with each other to see if there's an issue with the earbud or the cord.",
      "If the issue follows the earbud and not the cord, please check the mesh for dirt and earwax.",
      "If it's clogged, the issue might be caused by the dirt and needs to be cleaned safely.",
      "If the issue is persistent, or if it is caused by the cord, please reach out to our support team.",
    ],
  },
  {
    title: "Distorted sound in the earbuds",
    steps: [
      "Please try the headphones on a different device.",
      "Make sure that the connector is fully entered into the jack. Also please check that the pins are fully inserted into the earbuds.",
      "Please swap the earbuds with each other to see if there's an issue with the earbud or the cord.",
      "If the issue is persistent, please reach out to our support team.",
    ],
  },
  {
    title: "The earbuds experience disconnects and audio-loss",
    steps: [
      "Please try the headphones on a different device.",
      "Make sure that the connector is fully entered into the jack. Also please check that the pins are fully inserted into the earbuds.",
      "If the issue is persistent, please reach out to our support team.",
    ],
  },
  {
    title: "My earbuds are not quite there quality-wise",
    steps: [
      "We always recommend investing in a DAC/AMP amplifier which creates a more reliable connection between your PC and product.",
      "It may improve the overall experience of the product.",
    ],
  },
];

export const standardIEMCategory: ProductCategory = {
  name: "Headphones / IEMs",
  icon: "Headphones",
  issues: standardIEMIssues,
};

// ─── CONTROLLERS ────────────────────────────────────────────────────────

export const standardControllerIssues: TroubleshootingIssue[] = [
  {
    title: "The controller is experiencing stick drift",
    steps: [
      "Please try pressurized air to remove potential debris.",
      "No luck? You're welcome to reach out to our support team.",
    ],
  },
  {
    title: "The triggers register input by themselves / do not register input",
    steps: [
      "Please try pressurized air to remove potential debris.",
      "If you are still experiencing issues, you're welcome to reach out to our support team.",
    ],
  },
  {
    title: "The controller does not charge",
    steps: [
      "Please check the USB-C port for potential dust that may prohibit the device charging correctly. If there is dust, this needs to be removed safely.",
      "If the issue persists, try another cable, adapter and power outlet to eliminate accessories as the cause.",
      "Is the controller still experiencing issues? Please reach out to our support team.",
    ],
  },
];

export const standardControllerCategory: ProductCategory = {
  name: "Controllers",
  icon: "Gamepad2",
  issues: standardControllerIssues,
};

// ─── SCREENS / MONITORS ─────────────────────────────────────────────────

export const standardScreenIssues: TroubleshootingIssue[] = [
  {
    title: "The screen does not display any content",
    steps: [
      "Check that the monitor is connected to a power supply and that the power indicator lights on.",
      "Determine if your chosen cord is HDMI or DisplayPort, then check that the correct source is chosen on the monitor.",
      "If the screen still does not display any content, please try a different port on your device (PC/PS/etc.).",
      "If possible, try the monitor on a different device.",
      "Still experiencing issues? Please contact our support team.",
    ],
  },
  {
    title: "My screen has a dead pixel",
    steps: [
      "If possible, try to determine if the pixel is completely dead or just stuck. There are guides online on how to determine this.",
      "Rest your screen for 24 hours, as this might solve the issue.",
      "There are online tools that help restoring stuck pixels, for example JScreenFix.",
      "If none of these suggestions work, please contact our support team.",
    ],
  },
  {
    title: "The screen is flickering",
    steps: [
      "Unplug all the cables and insert them, being sure that they are inserted correctly.",
      "Try a different cable and a different port on your device.",
      "Try a different refresh rate (highest should work best).",
      "Move electrical devices as far away as possible.",
      "If the screen is still flickering, feel free to reach out to our support team.",
    ],
  },
  {
    title: "The monitor has a burn-in",
    steps: [
      "A burn-in is usually a result of the screen being heated up during a long period of time.",
      "This is considered user error as it is wear and tear.",
      "However, you're still welcome to reach out to us for an individual assessment.",
    ],
  },
  {
    title: "The screen displays incorrect color",
    steps: [
      "Reset the monitor following the company's product manual.",
      "Try a different cable.",
      "Still experiencing issues? Please contact our support team.",
    ],
  },
  {
    title: "My screen has vertical/horizontal lines across the screen",
    steps: [
      "Please try a different cable, as well as a different HDMI/DisplayPort on your device.",
      "If this does not help, please contact our support team.",
    ],
  },
];

export const standardScreenCategory: ProductCategory = {
  name: "Screens",
  icon: "Monitor",
  issues: standardScreenIssues,
};

// ─── ROUTERS ────────────────────────────────────────────────────────────

export const standardRouterIssues: TroubleshootingIssue[] = [
  {
    title: "I have no internet connection",
    steps: [
      "Restart the router. There are multiple guides online on how to do this.",
      "Contact your internet service provider for information regarding potential outage.",
      "Try a different ethernet cable to rule out accessory error.",
      "If these suggestions do not work, please contact our support team.",
    ],
  },
  {
    title: "The router does not turn on",
    steps: [
      "Please try a different power outlet.",
      "If available, try a different cable.",
      "Check the port for potential dust/debris that might need to be removed.",
      "Still experiencing issues? Please contact our support team.",
    ],
  },
  {
    title: "I experience slow internet speed",
    steps: [
      "Restart the router. There are multiple guides online on how to do this.",
      "Disconnect devices that are not in use, as they may overload the router.",
      "Place the router in an open space. If your space has many or thick walls, you might need range extenders to get good reception everywhere.",
      "If these solutions don't help, please reach out to our support team.",
    ],
  },
  {
    title: "I experience frequent disconnects",
    steps: [
      "Please note that connectivity cut-outs may be caused by the service provider.",
      "Restart the router.",
      "Update the firmware of the router.",
      "Plug the power cable into a different outlet. If available, try a different cable.",
      "If the disconnects are wired, please try a different ethernet cable.",
      "If none of these suggestions work, you can contact our support team for advice.",
    ],
  },
];

export const standardRouterCategory: ProductCategory = {
  name: "Routers",
  icon: "Wifi",
  issues: standardRouterIssues,
};

// ─── WIRELESS GAMING HEADPHONES ─────────────────────────────────────────

export const standardWirelessHeadphoneIssues: TroubleshootingIssue[] = [
  {
    title: "The headphones do not charge",
    steps: [
      "Try a different power outlet and a different cable.",
      "It might be a good idea to check the charging port for dust or debris that might interfere with the charging.",
    ],
  },
  {
    title: "The headphones turn off randomly",
    steps: [
      "Update the unit to the latest firmware to ensure functionality.",
      "Enter the product's software (if one is provided) and turn off the sleep timer settings.",
    ],
  },
  {
    title: "The headphones disconnect randomly",
    steps: [
      "Update the unit to the latest firmware to ensure functionality.",
      "Fully charge the unit to rule out battery issues.",
      "Make sure that the receiver is in a clear path to the unit and that it is inserted directly into the PC or console.",
    ],
  },
  {
    title: "There's no sound in one of the earpieces",
    steps: [
      "Update the unit to the latest firmware to ensure functionality.",
      "Reset the product.",
      "Please check for physical damage to the unit, as this voids the warranty.",
    ],
  },
  {
    title: "The volume is low",
    steps: [
      "If the unit has a physical volume wheel, try to adjust it.",
      "Enter your PC/console's audio settings to adjust the volume.",
      "The game/video/music platform you're using also has audio settings, please make sure to adjust them.",
    ],
  },
  {
    title: "Microphone does not work",
    steps: [
      "Update the unit to the latest firmware to ensure functionality.",
      "Usually there's a physical mute button on the headset, make sure this is not activated.",
      "Look at the selected audio input unit on your PC/console. Make sure it is the intended device.",
      "If your device is selected, make sure that the input volume is on an appropriate level.",
      "If your model has a removable microphone, make sure it is inserted correctly.",
    ],
  },
  {
    title: "The headphones turn on but do not connect",
    steps: [
      "Update both the headset and the receiver to the latest firmware.",
      "If possible, re-pair the dongle with the headset following the manufacturer's guide.",
      "Try a different USB port on your computer.",
      "Reset the device.",
    ],
  },
  {
    title: "The battery drains faster than expected",
    steps: [
      "The battery is subject to wear and tear, which means that the capacity is expected to drop as the product ages. Depending on how it has been used, the battery may not be covered by the warranty.",
      "Please test the battery by charging fully and time it until it runs out. Do not solely trust the battery level the software shows, as this is purely an estimation.",
      "Settings like RGB, sleep time and noise cancellation may affect the life expectancy of the unit. Adjusting these may improve the battery life.",
      "If you follow the troubleshooting steps and still consider your battery defective, please reach out to us for further help.",
    ],
  },
  {
    title: "My ear cushioning is in bad condition",
    steps: [
      "The ear cushions are subject to wear and tear, which means that the condition is expected to deteriorate as the cushion ages.",
      "Depending on how it has been used, the cushion is usually not covered by the warranty.",
      "If you believe that the cushion is supposed to last longer than it has, you're welcome to reach out to us for an individual assessment.",
    ],
  },
];

export const standardWirelessHeadphoneCategory: ProductCategory = {
  name: "Wireless Gaming Headphones",
  icon: "Headphones",
  issues: standardWirelessHeadphoneIssues,
};

// ─── WIRED GAMING HEADPHONES ────────────────────────────────────────────

export const standardWiredHeadphoneIssues: TroubleshootingIssue[] = [
  {
    title: "There's no sound",
    steps: [
      "If available, update the unit to the latest firmware to ensure functionality.",
      "Try a different port on your PC, and different cable if possible.",
      "The audio may be muted, or the volume may be low. Please adjust the setting in Windows and the application you're using (i.e. Spotify), to ensure that the audio is not turned off. If the unit has a physical volume wheel, try adjusting this as well.",
    ],
  },
  {
    title: "There's no sound in one of the earpieces",
    steps: [
      "If available, update the unit to the latest firmware to ensure functionality.",
      "Try a different port on your PC, and different cable if possible.",
    ],
  },
  {
    title: "Microphone does not work",
    steps: [
      "Update the unit to the latest firmware to ensure functionality.",
      "Usually there's a physical mute button on the headset, make sure this is not activated.",
      "Look at the selected audio input unit on your PC/console. Make sure it is the intended device.",
      "If your device is selected, make sure that the input volume is on an appropriate level.",
      "If your model has a removable microphone, make sure it is inserted correctly.",
    ],
  },
  {
    title: "The volume is low",
    steps: [
      "If the unit has a physical volume wheel, try to adjust it.",
      "Enter your PC/console's audio settings to adjust the volume.",
      "The game/video/music platform you're using also has audio settings, please make sure to adjust them.",
    ],
  },
  {
    title: "My ear cushioning is in bad condition",
    steps: [
      "The ear cushions are subject to wear and tear, which means that the condition is expected to deteriorate as the cushion ages.",
      "Depending on how it has been used, the cushion is usually not covered by the warranty.",
      "If you believe that the cushion is supposed to last longer than it has, you're welcome to reach out to us for an individual assessment.",
    ],
  },
  {
    title: "It sounds like there's a static noise in the headphones",
    steps: [
      "Check for physical indications of a defective device, i.e. that the cord is intact or that there's no dust or debris in the audio port that might interfere.",
      "Try the unit on a different device, to rule out the PC/console being the issue.",
      "If available, try a DAC/AMP as it usually resolves many audio issues.",
    ],
  },
];

export const standardWiredHeadphoneCategory: ProductCategory = {
  name: "Wired Gaming Headphones",
  icon: "Headphones",
  issues: standardWiredHeadphoneIssues,
};

// ─── MICROPHONES ────────────────────────────────────────────────────────

export const standardMicrophoneIssues: TroubleshootingIssue[] = [
  {
    title: "The microphone does not register any sound input",
    steps: [
      "Check that no physical mute buttons are activated.",
      "Make sure that the correct unit is selected on your PC/device.",
      "Make sure that your PC/device's settings aren't put on low volume.",
      "Please enter the software (if one is offered) and check the settings. Check if the input threshold is low, and if the mic registers any input at all.",
      "If none of the alternatives above work, please reach out to our support team.",
    ],
  },
  {
    title: "The volume of my voice is constantly low",
    steps: [
      "Please enter your PC's microphone settings and increase the input threshold.",
      "Download and enter the software (if one is offered) and check the settings.",
      "If you're still experiencing issues, please contact our support team.",
    ],
  },
  {
    title: "The physical buttons on the microphone do not work",
    steps: [
      "Please reach out to our support team for further assistance.",
    ],
  },
  {
    title: "The unit is not recognized as a device / a USB error message occurs",
    steps: [
      "Try a different USB port on your PC, preferably directly into the motherboard.",
      "Try a different cable to rule out issues with the accessories.",
      "If you're still experiencing issues, please contact our support team.",
    ],
  },
  {
    title: "My microphone picks up a lot of background noise",
    steps: [
      "As a first step, always limit the environmental things that might cause noise (fans, open doors/windows etc.).",
      "If the issue persists with normal interference, please check the software (if one is offered) for a setting that suppresses background noise.",
      "If a noise gate audio filter is not offered within a software, you're able to apply one through OBS. Please follow a tutorial online.",
      "Are you still experiencing issues? You're welcome to reach out to our support team.",
    ],
  },
  {
    title: "The microphone picks up a lot of static sound / the sound is distorted",
    steps: [
      "Please first try a different USB port and cable.",
      "Download the compatible software (if one is offered) and play around with the settings. Issues may be caused by too high input threshold, being too close to the microphone or the gain being too high etc.",
      "If none of the alternatives above work, please reach out to our support team.",
    ],
  },
  {
    title: "My microphone does not turn on",
    steps: [
      "Please first try a different cable, and then a different power source.",
      "If there's still no power, please check the USB-C port for dust and debris that might interfere with the power supply.",
      "Check that the USB-C is intact; if not, that might be the result of physical damage. Since physical damage is not covered under warranty, we will need to make an assessment.",
      "If the microphone is still experiencing issues, please reach out to our support team.",
    ],
  },
];

export const standardMicrophoneCategory: ProductCategory = {
  name: "Microphones",
  icon: "Mic",
  issues: standardMicrophoneIssues,
};

// ─── CAMERAS ────────────────────────────────────────────────────────────

export const standardCameraIssues: TroubleshootingIssue[] = [
  {
    title: "The camera disconnects randomly from the app",
    steps: [
      "Update the firmware of the unit.",
      "If you're using wireless internet connection, make sure that the router is within range to ensure stable connection.",
      "If you're using wired internet connection, make sure that both ends are inserted correctly. It might help to try a different cable as well.",
      "Reset the unit following the manufacturer's guide.",
    ],
  },
  {
    title: "The camera is unable to move in a certain direction",
    steps: [
      "Update the firmware of the unit.",
      "Check that no physical debris or residue are prohibiting functionality.",
      "Reset the unit following the manufacturer's guide.",
    ],
  },
  {
    title: "The camera lights red",
    steps: [
      "Try to reset the unit following the manufacturer's guide.",
    ],
  },
  {
    title: "The camera is unable to connect",
    steps: [
      "Reset the unit following the manufacturer's guide.",
      "Look for the product's sign of being ready to connect and follow the connection guide.",
      "If able to connect, make sure to update potential firmware to ensure future functionality.",
    ],
  },
];

export const standardCameraCategory: ProductCategory = {
  name: "Cameras",
  icon: "Camera",
  issues: standardCameraIssues,
};
